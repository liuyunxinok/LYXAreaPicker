//
//  LYXAreaTitleCollectionViewCell.h
//  LYXAreaPicker-demo
//
//  Created by 聚海微蓝-刘运新 on 2018/11/14.
//  Copyright © 2018年 聚海微蓝-刘运新. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LYXAreaTitleCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy) NSString *titleString;

@end

NS_ASSUME_NONNULL_END
