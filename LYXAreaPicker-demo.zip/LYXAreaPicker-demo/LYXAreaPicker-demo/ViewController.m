//
//  ViewController.m
//  LYXAreaPicker-demo
//
//  Created by 聚海微蓝-刘运新 on 2018/11/14.
//  Copyright © 2018年 聚海微蓝-刘运新. All rights reserved.
//

#import "ViewController.h"

//导入头文件
#import "LYXAreaPickerView.h"

@interface ViewController ()

@property (nonatomic, strong) UITextField *areaTextFiled;

@property (nonatomic, strong) UIButton *selectAreaButton;

@property (nonatomic, strong) LYXAreaPickerView *areaPickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.areaTextFiled];
    [self.view addSubview:self.selectAreaButton];
}



#pragma mark - 选择地区

- (void)selectAreaButtonDidClick{
    
    [self.areaPickerView showInView:self.view];
    //这里会造成循环引用注意！！！
    __weak typeof(self)weakSelf = self;
    self.areaPickerView.selectComplete = ^(NSString * _Nonnull area) {
        weakSelf.areaTextFiled.text = area;
    };
}


#pragma mark - UI

- (UITextField *)areaTextFiled{
    if (_areaTextFiled == nil) {
        _areaTextFiled = [[UITextField alloc] initWithFrame:CGRectMake(20, 200, 300, 50)];
        _areaTextFiled.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _areaTextFiled.layer.borderWidth = 0.5;
        _areaTextFiled.layer.cornerRadius = 4;
        _areaTextFiled.layer.masksToBounds = YES;
    }
    return _areaTextFiled;
}

- (UIButton *)selectAreaButton{
    if (_selectAreaButton == nil) {
        _selectAreaButton = [[UIButton alloc] initWithFrame:CGRectMake(100, 350, 150, 40)];
        [_selectAreaButton setTitle:@"选择地区" forState:UIControlStateNormal];
        [_selectAreaButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_selectAreaButton addTarget:self action:@selector(selectAreaButtonDidClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _selectAreaButton;
}

- (LYXAreaPickerView *)areaPickerView{
    if (_areaPickerView == nil) {
        _areaPickerView = [[LYXAreaPickerView alloc] initWithFrame:CGRectZero];
    }
    return _areaPickerView;
}

@end
